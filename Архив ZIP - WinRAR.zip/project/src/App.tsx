import React, { useState } from 'react';
import { Coins, Twitter, Send, ArrowRight, Target, Users, Rocket, BarChart as ChartBar, Plus, Minus, ArrowLeft, ArrowRightCircle } from 'lucide-react';

function App() {
  const [currentGoalIndex, setCurrentGoalIndex] = useState(0);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const goals = [
    {
      phase: "Phase 1",
      title: "Launch Goals",
      items: [
        { icon: <ChartBar className="w-5 h-5 text-purple-400" />, text: "Initial Market Cap: $100K" },
        { icon: <Users className="w-5 h-5 text-purple-400" />, text: "1,000+ Unique Holders" },
        { icon: <Rocket className="w-5 h-5 text-purple-400" />, text: "PUMP FUN Listing" }
      ]
    },
    {
      phase: "Phase 2",
      title: "Growth Goals",
      items: [
        { icon: <ChartBar className="w-5 h-5 text-purple-400" />, text: "Market Cap: $1M+" },
        { icon: <Users className="w-5 h-5 text-purple-400" />, text: "5,000+ Community Members" },
        { icon: <Rocket className="w-5 h-5 text-purple-400" />, text: "Major CEX Listings" }
      ]
    },
    {
      phase: "Phase 3",
      title: "Expansion Goals",
      items: [
        { icon: <ChartBar className="w-5 h-5 text-purple-400" />, text: "Market Cap: $10M+" },
        { icon: <Users className="w-5 h-5 text-purple-400" />, text: "20,000+ Holders" },
        { icon: <Rocket className="w-5 h-5 text-purple-400" />, text: "Global Marketing Campaign" }
      ]
    },
    {
      phase: "Phase 4",
      title: "Moon Mission",
      items: [
        { icon: <ChartBar className="w-5 h-5 text-purple-400" />, text: "Market Cap: $50M+" },
        { icon: <Users className="w-5 h-5 text-purple-400" />, text: "100,000+ Community" },
        { icon: <Rocket className="w-5 h-5 text-purple-400" />, text: "Top 100 Crypto" }
      ]
    }
  ];

  const navItems = [
    { href: "#story", label: "Story" },
    { href: "#goals", label: "Goals" },
    { href: "#faq", label: "FAQ" },
    { href: "#buy", label: "Buy" }
  ];

  const faqs = [
    {
      question: "Is this an official product?",
      answer: "Yes, $ZELENSKY is an official meme coin project built on the Solana blockchain with a dedicated team and clear roadmap."
    },
    {
      question: "How can I buy $ZELENSKY?",
      answer: "You can buy $ZELENSKY on PUMP FUN DEX using Solana (SOL). Connect your Phantom wallet, swap SOL for $ZELENSKY, and join our community!"
    },
    {
      question: "What blockchain is $ZELENSKY built on?",
      answer: "We're built on Solana for lightning-fast transactions, minimal fees, and maximum scalability."
    },
    {
      question: "Is the contract audited?",
      answer: "Yes, our smart contract has been fully audited by leading security firms to ensure maximum safety for our community."
    },
    {
      question: "What makes $ZELENSKY unique?",
      answer: "We combine the fun of meme coins with real utility, backed by a passionate community and built on Solana's powerful infrastructure."
    },
    {
      question: "When will $ZELENSKY be listed on major exchanges?",
      answer: "We're actively working on CEX listings as part of our roadmap. Follow our social media for the latest updates!"
    },
    {
      question: "How can I get involved in the community?",
      answer: "Join our Telegram and Twitter communities, participate in discussions, and help spread the word about $ZELENSKY!"
    }
  ];

  return (
    <div className="min-h-screen bg-[#0F051D] text-white">
      {/* Hero Section */}
      <div className="relative min-h-screen">
        {/* Animated background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 to-[#0F051D]"></div>
          {/* Dynamic crypto-themed background */}
          <div className="absolute top-0 left-0 w-full h-full bg-[url('https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=2832')] bg-cover bg-center opacity-5"></div>
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJub25lIi8+PGNpcmNsZSBjeD0iMTAwIiBjeT0iMTAwIiByPSI0MCIgc3Ryb2tlPSJyZ2JhKDEwMywgNTgsIDE4MywgMC4xKSIgc3Ryb2tlLXdpZHRoPSIyIi8+PC9zdmc+')] opacity-20"></div>
          {/* Animated grid effect */}
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(rgba(103, 58, 183, 0.1) 1px, transparent 1px), 
                             linear-gradient(90deg, rgba(103, 58, 183, 0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px',
            animation: 'scroll 20s linear infinite'
          }}></div>
        </div>

        <div className="relative">
          <nav className="container mx-auto px-4 py-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Coins className="w-8 h-8 text-purple-400" />
                <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">$ZELENSKY</span>
              </div>
              
              {/* Desktop Navigation */}
              <div className="hidden md:flex gap-8">
                {navItems.map((item) => (
                  <a
                    key={item.href}
                    href={item.href}
                    className="relative text-lg font-medium text-gray-300 hover:text-white transition-colors group"
                  >
                    {item.label}
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-purple-400 scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>
                  </a>
                ))}
              </div>

              {/* Mobile Navigation Button */}
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden text-purple-400 hover:text-purple-300 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            </div>

            {/* Mobile Navigation Menu */}
            {isMenuOpen && (
              <div className="absolute top-full left-0 right-0 bg-[#0F051D]/95 backdrop-blur-lg border-t border-purple-500/20 py-4 md:hidden">
                <div className="container mx-auto px-4 flex flex-col gap-4">
                  {navItems.map((item) => (
                    <a
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsMenuOpen(false)}
                      className="text-lg font-medium text-gray-300 hover:text-white transition-colors"
                    >
                      {item.label}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </nav>

          <div className="container mx-auto px-4 py-20">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="text-left">
                <h1 className="text-7xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text leading-tight">
                  The Most Based Meme Coin on Solana
                </h1>
                <p className="text-xl text-gray-300 mb-12">
                  Join the revolution with $ZELENSKY - Where memes meet momentum on the Solana blockchain
                </p>
                <div className="flex gap-6">
                  <button className="bg-gradient-to-r from-purple-500 to-pink-500 px-8 py-3 rounded-full font-semibold flex items-center gap-2 hover:opacity-90 transition-opacity">
                    Buy Now <ArrowRight className="w-5 h-5" />
                  </button>
                  <button className="border border-purple-500 hover:bg-purple-500/20 px-8 py-3 rounded-full font-semibold transition-colors">
                    Chart
                  </button>
                </div>
              </div>
              <div className="flex justify-center">
                {/* Placeholder for logo.png */}
                <div className="w-96 h-96 rounded-full bg-purple-500/10 border-2 border-purple-500/20 flex items-center justify-center text-purple-400">
                  <span className="text-lg">Logo Coming Soon</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-purple-900/10 backdrop-blur-xl py-16 border-t border-b border-purple-500/20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="p-6 rounded-2xl bg-purple-900/20 backdrop-blur-sm">
              <h3 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">24/7</h3>
              <p className="text-purple-300">Active Support</p>
            </div>
            <div className="p-6 rounded-2xl bg-purple-900/20 backdrop-blur-sm">
              <h3 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">100%</h3>
              <p className="text-purple-300">Community Driven</p>
            </div>
            <div className="p-6 rounded-2xl bg-purple-900/20 backdrop-blur-sm">
              <h3 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">Audited</h3>
              <p className="text-purple-300">Smart Contract</p>
            </div>
            <div className="p-6 rounded-2xl bg-purple-900/20 backdrop-blur-sm">
              <h3 className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">Solana</h3>
              <p className="text-purple-300">Powered</p>
            </div>
          </div>
        </div>
      </div>

      {/* Story Section */}
      <div id="story" className="container mx-auto px-4 py-24">
        <div className="max-w-4xl mx-auto">
          <div className="bg-purple-900/10 p-8 md:p-12 rounded-3xl backdrop-blur-sm border border-purple-500/20">
            <h2 className="text-4xl font-bold mb-8 text-center bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">My Story</h2>
            <div className="text-gray-200 space-y-6 text-lg leading-relaxed">
              <p>
                Здравствуйте! My name is John, and $ZELENSKY is my first venture into the exciting world of meme coins.
                This project represents more than just another token – it's the culmination of my dream to create something
                meaningful in the crypto space.
              </p>
              <p>
                As a newcomer to the crypto scene, I've been fascinated by the power of community-driven projects.
                While $ZELENSKY may start on PUMP FUN, my vision extends far beyond just another pump and dump token.
                I'm committed to building a lasting community and bringing real utility to this project.
              </p>
              <p>
                I pledge to actively promote and develop this project, engaging with the community every step of the way.
                This isn't just about making a quick profit – it's about creating something we can all be proud of.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Goals Section */}
      <div id="goals" className="py-24 bg-purple-900/10">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-16 text-center bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">
            Project Milestones
          </h2>
          <div className="max-w-4xl mx-auto relative">
            <button 
              onClick={() => setCurrentGoalIndex((prev) => (prev > 0 ? prev - 1 : goals.length - 1))}
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 text-purple-400 hover:text-purple-300 transition-colors md:block hidden"
            >
              <ArrowLeft className="w-8 h-8" />
            </button>
            <button 
              onClick={() => setCurrentGoalIndex((prev) => (prev < goals.length - 1 ? prev + 1 : 0))}
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 text-purple-400 hover:text-purple-300 transition-colors md:block hidden"
            >
              <ArrowRightCircle className="w-8 h-8" />
            </button>
            
            <div className="bg-purple-900/10 p-8 rounded-3xl backdrop-blur-sm border border-purple-500/20">
              <Target className="w-12 h-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2 text-center">{goals[currentGoalIndex].phase}</h3>
              <h4 className="text-xl text-purple-400 mb-8 text-center">{goals[currentGoalIndex].title}</h4>
              <ul className="space-y-4">
                {goals[currentGoalIndex].items.map((item, index) => (
                  <li key={index} className="flex items-center gap-3 text-gray-200">
                    {item.icon}
                    {item.text}
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex justify-center gap-2 mt-8">
              {goals.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentGoalIndex(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentGoalIndex ? 'bg-purple-400' : 'bg-purple-900'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div id="faq" className="container mx-auto px-4 py-24">
        <h2 className="text-4xl font-bold mb-16 text-center bg-gradient-to-r from-purple-400 to-pink-400 text-transparent bg-clip-text">
          Frequently Asked Questions
        </h2>
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-purple-900/10 rounded-2xl backdrop-blur-sm border border-purple-500/20 overflow-hidden"
            >
              <button
                className="w-full px-6 py-4 text-left flex justify-between items-center"
                onClick={() => setOpenFaqIndex(openFaqIndex === index ? null : index)}
              >
                <span className="font-semibold text-lg">{faq.question}</span>
                {openFaqIndex === index ? (
                  <Minus className="w-5 h-5 text-purple-400" />
                ) : (
                  <Plus className="w-5 h-5 text-purple-400" />
                )}
              </button>
              <div
                className={`px-6 transition-all duration-300 ease-in-out ${
                  openFaqIndex === index ? 'max-h-48 py-4' : 'max-h-0'
                } overflow-hidden text-gray-300`}
              >
                {faq.answer}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-purple-500/20 py-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-center gap-8">
            <a href="#" className="text-purple-400 hover:text-purple-300 transition-colors transform hover:scale-110">
              <Twitter className="w-8 h-8" />
            </a>
            <a href="#" className="text-purple-400 hover:text-purple-300 transition-colors transform hover:scale-110">
              <Send className="w-8 h-8" />
            </a>
          </div>
          <p className="text-center text-gray-400 mt-8">
            © 2024 $ZELENSKY. Built on Solana.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;